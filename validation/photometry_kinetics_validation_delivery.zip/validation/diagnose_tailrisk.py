"""
Follow-up to validation/diagnose_trial_timing.py: the median inter-event gap
is the wrong statistic for judging window safety -- risk lives in the LEFT
TAIL (the fraction of trials with a short gap), and specifically whether
that fast-tail subset is enriched for a particular streak/tercile state
(which would bias FIR/DECISION_WINDOW_S results in a state-dependent way
even though their windows are short). Separately, REWARD_WINDOW_S=(1.0,3.0)
is checked for degree of contamination (not just whether ANY exists), since
its upper bound is already well past the median gap for most trials.

Step 1: left-tail percentiles (1st/5th/10th) of the same inter-event gaps
computed in diagnose_trial_timing.py, pooled and per mouse.
Step 2: for the gap<1.0s subset (FIR's post-event window AND
DECISION_WINDOW_S's upper bound -- both are exactly 1.0s in this pipeline,
config/params.py's DEFAULT_LAG_SECONDS=1.0 and DECISION_WINDOW_S=(0,1.0),
so one threshold covers both), test whether Rolling_Accuracy tercile is
over/under-represented relative to its overall (~1/3) base rate.
Step 4: for REWARD_WINDOW_S=(1.0,3.0), compute a continuous per-trial
contamination_fraction (what fraction of the 2s window falls after the
next event's onset) and test whether it correlates with tercile.

Does not modify any pipeline code/config. Does not commit/push anything.

Usage: python validation/diagnose_tailrisk.py [out_dir]
"""

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency, mannwhitneyu

sys.path.insert(0, str(Path(__file__).parent.parent))

from validation.diagnose_trial_timing import load_and_compute_gaps  # noqa: E402
from run_age_comparison import cliffs_delta, bootstrap_median_diff_ci  # noqa: E402

FIR_DECISION_THRESHOLD_S = 1.0  # DEFAULT_LAG_SECONDS == DECISION_WINDOW_S upper bound, both 1.0s
REWARD_WINDOW_S = (1.0, 3.0)


def add_terciles(tt):
    tt = tt.copy()
    tt["accuracy_tercile"] = (
        tt.groupby("mouse")["Rolling_Accuracy"]
        .transform(lambda s: pd.qcut(s.rank(method="first"), 3, labels=["low", "mid", "high"]))
    )
    return tt


def step1_left_tail(valid, out_dir):
    print("=" * 78)
    print("STEP 1-2 DELIVERABLE: left-tail gap risk + fast-tail tercile skew")
    print("=" * 78)
    print("\n--- Step 1: left-tail percentiles of inter-event gap ---\n")

    rows = []
    for col, label in [("next_center_in_gap", "outcome->next_center_in"),
                       ("next_side_in_gap", "outcome->next_side_in")]:
        vals = valid[col].dropna().to_numpy()
        p1, p5, p10 = np.percentile(vals, [1, 5, 10])
        rows.append(dict(mouse="POOLED (all mice)", gap=label, n=len(vals), p1=p1, p5=p5, p10=p10))
        for mouse, g in valid.groupby("mouse"):
            v = g[col].dropna().to_numpy()
            p1m, p5m, p10m = np.percentile(v, [1, 5, 10])
            rows.append(dict(mouse=mouse, gap=label, n=len(v), p1=p1m, p5=p5m, p10=p10m))

    pct_df = pd.DataFrame(rows)
    pct_df.to_csv(out_dir / "step1_gap_percentiles.csv", index=False)
    print(pct_df.to_string(index=False))

    flagged = pct_df[(pct_df["mouse"] != "POOLED (all mice)") & (pct_df["p5"] < 1.0)]
    print(f"\nMice/gap-types flagged with 5th percentile < 1.0s:")
    if len(flagged):
        print(flagged.to_string(index=False))
    else:
        print("  none")
    return pct_df, flagged


def step2_fast_tail_skew(valid, out_dir, threshold=FIR_DECISION_THRESHOLD_S):
    print(f"\n--- Step 2: is the gap<{threshold}s subset skewed by tercile? "
          f"(threshold covers both FIR's post-event window and DECISION_WINDOW_S's upper bound) ---\n")

    rows = []
    for col, label in [("next_center_in_gap", "outcome->next_center_in"),
                       ("next_side_in_gap", "outcome->next_side_in (same event type as FIR/DECISION_WINDOW_S measure)")]:
        fast = (valid[col] < threshold)

        # pooled
        ct = pd.crosstab(valid["accuracy_tercile"], fast)
        if ct.shape[1] == 2 and (ct.to_numpy() > 0).all():
            chi2, p, dof, exp = chi2_contingency(ct)
        else:
            chi2, p = np.nan, np.nan
        frac_fast_by_tercile = valid.groupby("accuracy_tercile")[col].apply(lambda s: (s < threshold).mean())
        overall_frac_fast = fast.mean()
        rows.append(dict(
            mouse="POOLED (all mice)", gap=label, n_fast=int(fast.sum()), n_total=len(valid),
            overall_frac_fast=overall_frac_fast,
            frac_fast_low=frac_fast_by_tercile.get("low", np.nan),
            frac_fast_mid=frac_fast_by_tercile.get("mid", np.nan),
            frac_fast_high=frac_fast_by_tercile.get("high", np.nan),
            chi2=chi2, chi2_p=p,
        ))

        for mouse, g in valid.groupby("mouse"):
            fast_m = g[col] < threshold
            ct_m = pd.crosstab(g["accuracy_tercile"], fast_m)
            if ct_m.shape[1] == 2 and (ct_m.to_numpy() > 0).all() and ct_m.to_numpy().sum() > 20:
                chi2m, pm, _, _ = chi2_contingency(ct_m)
            else:
                chi2m, pm = np.nan, np.nan
            frac_by_t = g.groupby("accuracy_tercile")[col].apply(lambda s: (s < threshold).mean())
            rows.append(dict(
                mouse=mouse, gap=label, n_fast=int(fast_m.sum()), n_total=len(g),
                overall_frac_fast=fast_m.mean(),
                frac_fast_low=frac_by_t.get("low", np.nan),
                frac_fast_mid=frac_by_t.get("mid", np.nan),
                frac_fast_high=frac_by_t.get("high", np.nan),
                chi2=chi2m, chi2_p=pm,
            ))

    skew_df = pd.DataFrame(rows)
    skew_df.to_csv(out_dir / "step2_fasttail_tercile_skew.csv", index=False)
    print(skew_df.to_string(index=False))
    return skew_df


def step4_reward_window_contamination(valid, out_dir):
    print("\n" + "=" * 78)
    print("STEP 3-4 DELIVERABLE (priority: Step 4 first, per user's request)")
    print("=" * 78)
    print(f"\n--- Step 4: REWARD_WINDOW_S={REWARD_WINDOW_S} contamination fraction/degree ---\n")

    lo, hi = REWARD_WINDOW_S
    span = hi - lo
    gap = valid["next_side_in_gap"]  # the same-event-type contamination source

    contamination_fraction = np.clip((hi - gap) / span, 0.0, 1.0)
    valid = valid.assign(contamination_fraction=contamination_fraction)

    any_contam = (contamination_fraction > 0)
    print(f"Fraction of trials with ANY contamination inside REWARD_WINDOW_S: {any_contam.mean():.1%}")
    print(f"Fraction with the window FULLY contaminated (next side_in before window even starts, gap<={lo}s): "
          f"{(gap <= lo).mean():.1%}")
    print(f"Mean contamination_fraction (0=none, 1=fully contaminated) across ALL trials: "
          f"{contamination_fraction.mean():.3f}")
    print(f"Median contamination_fraction: {contamination_fraction.median():.3f}")

    print("\nPer-mouse contamination_fraction summary:")
    per_mouse = valid.groupby("mouse")["contamination_fraction"].agg(["mean", "median", lambda s: (s > 0).mean()])
    per_mouse.columns = ["mean_contam_frac", "median_contam_frac", "frac_any_contam"]
    print(per_mouse.to_string())
    per_mouse.to_csv(out_dir / "step4_reward_window_contamination_per_mouse.csv")

    print("\nDoes contamination_fraction correlate with Rolling_Accuracy tercile?")
    rows = []
    low = valid.loc[valid["accuracy_tercile"] == "low", "contamination_fraction"].to_numpy()
    high = valid.loc[valid["accuracy_tercile"] == "high", "contamination_fraction"].to_numpy()
    stat, p = mannwhitneyu(low, high, alternative="two-sided")
    delta = cliffs_delta(low, high)
    ci_lo, ci_hi = bootstrap_median_diff_ci(low, high)
    rows.append(dict(mouse="POOLED (all mice)", n_low=len(low), n_high=len(high),
                      median_low=np.median(low), median_high=np.median(high),
                      median_diff=np.median(low) - np.median(high),
                      ci_lo=ci_lo, ci_hi=ci_hi, cliffs_delta=delta, mwu_p=p))
    for mouse, g in valid.groupby("mouse"):
        low = g.loc[g["accuracy_tercile"] == "low", "contamination_fraction"].to_numpy()
        high = g.loc[g["accuracy_tercile"] == "high", "contamination_fraction"].to_numpy()
        if len(low) < 5 or len(high) < 5:
            continue
        stat, p = mannwhitneyu(low, high, alternative="two-sided")
        delta = cliffs_delta(low, high)
        ci_lo, ci_hi = bootstrap_median_diff_ci(low, high)
        rows.append(dict(mouse=mouse, n_low=len(low), n_high=len(high),
                          median_low=np.median(low), median_high=np.median(high),
                          median_diff=np.median(low) - np.median(high),
                          ci_lo=ci_lo, ci_hi=ci_hi, cliffs_delta=delta, mwu_p=p))
    contam_tercile_df = pd.DataFrame(rows)
    contam_tercile_df.to_csv(out_dir / "step4_contamination_by_tercile.csv", index=False)
    print(contam_tercile_df.to_string(index=False))

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].hist(contamination_fraction, bins=40, color="crimson", alpha=0.8)
    axes[0].set_xlabel("contamination_fraction of REWARD_WINDOW_S (1.0-3.0s)")
    axes[0].set_ylabel("trial count")
    axes[0].set_title(f"All trials (mean={contamination_fraction.mean():.2f})")

    for tercile, color in [("low", "crimson"), ("mid", "gray"), ("high", "seagreen")]:
        vals = valid.loc[valid["accuracy_tercile"] == tercile, "contamination_fraction"]
        axes[1].hist(vals, bins=30, histtype="step", lw=1.8, color=color, density=True,
                     label=f"{tercile} (med={vals.median():.2f})")
    axes[1].set_xlabel("contamination_fraction")
    axes[1].set_ylabel("density")
    axes[1].legend(fontsize=8)
    axes[1].set_title("By Rolling_Accuracy tercile")
    fig.suptitle("REWARD_WINDOW_S (1.0-3.0s) contamination degree")
    fig.tight_layout()
    fig.savefig(out_dir / "step4_reward_window_contamination.png", dpi=140)
    print(f"\nSaved {out_dir / 'step4_reward_window_contamination.png'}")

    return contam_tercile_df


def main(out_dir="/tmp/tailrisk_diag_out"):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    tt = load_and_compute_gaps()
    valid = tt.loc[~tt["is_last_trial_of_session"]].copy()
    valid = add_terciles(valid)

    step1_left_tail(valid, out_dir)
    step2_fast_tail_skew(valid, out_dir)
    step4_reward_window_contamination(valid, out_dir)

    print(f"\nAll outputs saved to {out_dir}")


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "/tmp/tailrisk_diag_out"
    main(out)
