"""
Phase 3 of the contamination follow-up: adjudicate, PER MOUSE, between three
explanations for the Rolling_Accuracy-tercile divergence found in
diagnose_kinetics_shape.py: (a) a real slow single-trial signal, (b) a
contamination-AMOUNT artifact (how much of the window overlaps the next
trial), (c) a contamination-CONTENT artifact (whether the next trial's own
outcome correlates with the current trial's tercile, independent of how
much of the window it occupies). WCL24 already falsifies "amount alone
explains everything": it has LESS contamination on recent-loss trials
(diagnose_tailrisk.py) yet shows the SAME divergence as WCL29/WCL31 (which
have MORE contamination on recent-loss trials).

Step 1: censored-window reanalysis -- mask each trial's z-scored window to
NaN beyond that trial's own next_side_in_gap (no fixed window bound), so no
average includes truly-next-trial samples. Refit onset/decay on the
resulting nanmean trace, tracking effective_n(t) throughout.

Step 2: outcome-autocorrelation -- does the next trial's own outcome
correlate with the current trial's tercile, plainly and (the sharper test)
within contamination_fraction quartiles (so if it survives even in the
lowest-contamination quartile, that's content, not amount).

Step 3: an explicit per-mouse verdict table (not a cohort-wide conclusion).

Reuses (does not recompute from scratch): load_and_compute_gaps() from
diagnose_trial_timing.py, cliffs_delta/bootstrap_median_diff_ci from
run_age_comparison.py, compute_onset_and_decay from alignment.kinetics, and
the contamination_fraction formula/tercile convention from
diagnose_tailrisk.py.

Read-only; does not modify any pipeline code/config; does not commit/push.

Usage: python validation/diagnose_censored_kinetics.py [out_dir]
"""

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency

sys.path.insert(0, str(Path(__file__).parent.parent))

from alignment.kinetics import compute_onset_and_decay  # noqa: E402
from validation.diagnose_trial_timing import load_and_compute_gaps  # noqa: E402
from run_age_comparison import cliffs_delta, bootstrap_median_diff_ci  # noqa: E402

DATA_DIR = Path("outputs_fixed/rpe_analysis_pooled")
REWARD_WINDOW_S = (1.0, 3.0)
KINETICS_METRIC_WINDOW_S = (0.0, 3.0)
MIN_USABLE_S = 0.5
FEATURED_MICE = ["WCL24", "WCL29", "WCL31"]
RNG = np.random.default_rng(0)


def load_everything():
    tt = load_and_compute_gaps()  # index-aligned with peth_windows.npz rows
    peth = np.load(DATA_DIR / "peth_windows.npz")
    z, t = peth["zscore_windows"], peth["peth_time"]

    # Sign-orient per mouse (all reward trials for that mouse share one sign,
    # matching diagnose_kinetics_shape.py's convention) -- reward trials are
    # confirmed negative-going in this dataset, so fitting raw z without this
    # flip makes every peak-finding step fail (peak_value <= 0).
    z = z.astype(float).copy()
    win_mask = (t >= KINETICS_METRIC_WINDOW_S[0]) & (t <= KINETICS_METRIC_WINDOW_S[1])
    for mouse, idx in tt.groupby("mouse").groups.items():
        reward_idx = tt.loc[idx][tt.loc[idx, "was_rewarded"]].index.to_numpy()
        if len(reward_idx) == 0:
            continue
        sign = 1.0 if z[reward_idx][:, win_mask].mean() >= 0 else -1.0
        z[reward_idx] *= sign

    tt = tt.copy()
    tt["accuracy_tercile"] = (
        tt.groupby("mouse")["Rolling_Accuracy"]
        .transform(lambda s: pd.qcut(s.rank(method="first"), 3, labels=["low", "mid", "high"]))
    )

    # next-trial outcome, same grouping/sorting convention as next_side_in_s
    parts = []
    for (mouse, date), g in tt.groupby(["mouse", "date"], sort=False):
        g = g.sort_values("side_in_s").copy()
        g["next_was_rewarded"] = g["was_rewarded"].shift(-1)
        parts.append(g)
    tt = pd.concat(parts, ignore_index=False).sort_index()

    lo, hi = REWARD_WINDOW_S
    span = hi - lo
    tt["contamination_fraction"] = np.clip((hi - tt["next_side_in_gap"]) / span, 0.0, 1.0)

    return tt, z, t


def censored_mean_and_n(z, t, idx, censor_times):
    """idx: row indices into z. censor_times: same length, NaN = no censoring."""
    windows = z[idx].astype(float).copy()
    for i, c in enumerate(censor_times):
        if not np.isnan(c):
            windows[i, t >= c] = np.nan
    effective_n = np.sum(~np.isnan(windows), axis=0)
    mean_trace = np.nanmean(windows, axis=0)
    return mean_trace, effective_n


def breakpoints(effective_n, n_total, t):
    post = t >= 0
    frac = np.where(post, effective_n / max(n_total, 1), 1.0)
    def last_above(thresh):
        ok = np.where(post & (frac >= thresh))[0]
        return t[ok[-1]] if len(ok) else 0.0
    t_full = last_above(1e-9)
    t_50 = last_above(0.5)
    t_25 = last_above(0.25)
    return t_full, t_50, t_25


def get_group(tt, mouse, tercile, was_rewarded=True):
    sub = tt[(tt["mouse"] == mouse) & (tt["was_rewarded"] == was_rewarded) & (tt["accuracy_tercile"] == tercile)]
    return sub


def step1_censored_reanalysis(tt, z, t, out_dir):
    print("=" * 78)
    print("STEP 1: censored-window tercile-divergence reanalysis")
    print("=" * 78)
    print("\nNote: exponential-fit success/failure turns out to be a fragile metric at the\n"
          "tercile-subgroup level (smaller n than the full-population fits reported\n"
          "earlier) -- most tercile-level fits fail regardless of censoring, uncensored\n"
          "included. The primary evidence below is therefore the DIVERGENCE MAGNITUDE\n"
          "(low-vs-high tercile mean difference over 1.0-3.0s) before vs. after\n"
          "censoring, not fit success. Fit attempts are reported as supplementary color.\n")

    mice = sorted(tt["mouse"].unique())
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
    summary_rows = []
    traces_by_mouse = {}  # mouse -> {tercile: (mean_u, mean_c, eff_n, n_kept)}
    compare_mask = (t >= 1.0) & (t <= 3.0)

    for mouse in mice:
        traces_by_mouse[mouse] = {}
        for tercile in ["low", "high"]:
            sub = get_group(tt, mouse, tercile)
            idx_all = sub.index.to_numpy()
            gap = sub["next_side_in_gap"].to_numpy()
            keep = np.isnan(gap) | (gap >= MIN_USABLE_S)
            n_total, n_kept = len(idx_all), int(keep.sum())
            frac_excluded = 1 - n_kept / n_total if n_total else np.nan

            idx = idx_all[keep]
            censor = gap[keep]
            mean_c, eff_n = censored_mean_and_n(z, t, idx, censor)
            t_full, t_50, t_25 = breakpoints(eff_n, n_kept, t)

            fit_window = (0.0, min(t_full, KINETICS_METRIC_WINDOW_S[1]))
            onset_c, tau_c, r2_c, diag_c = compute_onset_and_decay(mean_c, t, fit_window)
            fit_window_50 = (0.0, min(t_50, KINETICS_METRIC_WINDOW_S[1]))
            onset_50, tau_50, r2_50, diag_50 = compute_onset_and_decay(mean_c, t, fit_window_50)

            # uncensored comparison (fixed window, same trials pre-exclusion)
            windows_u = z[idx]
            mean_u = windows_u.mean(axis=0)
            onset_u, tau_u, r2_u, diag_u = compute_onset_and_decay(mean_u, t, KINETICS_METRIC_WINDOW_S)

            traces_by_mouse[mouse][tercile] = (mean_u, mean_c, eff_n, n_kept)

            summary_rows.append(dict(
                mouse=mouse, tercile=tercile, n_total=n_total, n_kept=n_kept,
                frac_excluded_short_window=frac_excluded,
                t_full=t_full, t_50=t_50, t_25=t_25,
                tau_uncensored=tau_u, tau_censored_full=tau_c, tau_censored_at_t50=tau_50,
                skip_uncensored=diag_u["skip_reason"], skip_censored_full=diag_c["skip_reason"],
                skip_censored_t50=diag_50["skip_reason"],
            ))

        # Divergence magnitude: high-minus-low mean difference, uncensored vs.
        # censored. CRITICAL: do NOT average over a fixed 1.0-3.0s window --
        # effective_n collapses well before 3.0s for most mice, and the
        # resulting censored mean in that low-N tail swings wildly (confirmed
        # visually: censored and uncensored traces track closely while N is
        # high, then diverge sharply exactly where N craters -- a small-sample
        # artifact, not signal). Instead use a PER-MOUSE, adequately-powered
        # window: [1.0s, min(t_50_low, t_50_high)] -- both terciles must still
        # have >=50% of their (post-exclusion) trials contributing throughout.
        mu_low, mc_low, effn_low, nk_low = traces_by_mouse[mouse]["low"]
        mu_high, mc_high, effn_high, nk_high = traces_by_mouse[mouse]["high"]
        _, t50_low, _ = breakpoints(effn_low, nk_low, t)
        _, t50_high, _ = breakpoints(effn_high, nk_high, t)
        well_powered_end = min(t50_low, t50_high)
        well_powered_mask = (t >= 1.0) & (t <= well_powered_end)
        window_too_short = well_powered_end <= 1.2  # need >=~0.2s of comparison window

        if window_too_short:
            div_uncensored, div_censored, mean_shared_coverage = np.nan, np.nan, np.nan
        else:
            div_uncensored = np.mean((mu_high - mu_low)[well_powered_mask])
            with np.errstate(invalid="ignore"):
                div_censored = np.nanmean((mc_high - mc_low)[well_powered_mask])
            shared_eff_frac = np.minimum(effn_low / max(nk_low, 1), effn_high / max(nk_high, 1))
            mean_shared_coverage = shared_eff_frac[well_powered_mask].mean()
        for row in summary_rows:
            if row["mouse"] == mouse and row["tercile"] == "low":
                row["divergence_uncensored_1to3s"] = div_uncensored
                row["divergence_censored_1to3s"] = div_censored
                row["divergence_shrinkage_frac"] = (
                    1 - div_censored / div_uncensored if div_uncensored not in (0, np.nan) and not np.isnan(div_uncensored) else np.nan
                )
                row["mean_shared_coverage_1to3s"] = mean_shared_coverage
                row["well_powered_window_end_s"] = well_powered_end
                row["window_too_short"] = window_too_short

        if mouse in FEATURED_MICE:
            ax = axes[FEATURED_MICE.index(mouse)]
            for tercile, color in [("low", "crimson"), ("high", "seagreen")]:
                sub = get_group(tt, mouse, tercile)
                idx_all = sub.index.to_numpy()
                gap = sub["next_side_in_gap"].to_numpy()
                keep = np.isnan(gap) | (gap >= MIN_USABLE_S)
                idx, censor = idx_all[keep], gap[keep]

                mean_u = z[idx].mean(axis=0)
                mean_c, eff_n = censored_mean_and_n(z, t, idx, censor)

                ax.plot(t, mean_u, ls="--", color=color, lw=1.5, alpha=0.7,
                        label=f"{tercile} uncensored")
                ax.plot(t, mean_c, ls="-", color=color, lw=2.2, label=f"{tercile} censored")

                ax2 = ax.twinx() if tercile == "low" else ax._twin
                if tercile == "low":
                    ax._twin = ax2
                ax2.fill_between(t, 0, eff_n / len(idx), color=color, alpha=0.08)
                ax2.set_ylim(0, 1.05)
                ax2.set_ylabel("effective N / N", fontsize=8)

            ax.axvline(0, color="gray", ls=":", lw=1)
            ax.axhline(0, color="gray", ls="--", lw=0.5)
            ax.set_title(f"{mouse}", fontsize=11)
            ax.set_xlabel("time from outcome (s)")
            ax.set_xlim(-2, 5.4)
            ax.legend(fontsize=7, loc="upper left")

    axes[0].set_ylabel("z-score (reward trials)")
    fig.suptitle("Censored (solid) vs. uncensored (dashed) tercile means -- shaded = effective N/N")
    fig.tight_layout()
    fig.savefig(out_dir / "step1_censored_vs_uncensored_featured.png", dpi=140)
    print(f"Saved {out_dir / 'step1_censored_vs_uncensored_featured.png'}")

    summary_df = pd.DataFrame(summary_rows)
    summary_df.to_csv(out_dir / "step1_censored_fit_summary.csv", index=False)
    pd.set_option("display.width", 200)
    print(summary_df.to_string(index=False))
    return summary_df


def step1_subset_sweep(tt, z, t, out_dir, sizes=(5, 10, 20, 40, 80)):
    print("\n--- Step 1 (censored subset-size sweep), featured mice, 'low' tercile, reward ---\n")
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    for ax, mouse in zip(axes, FEATURED_MICE):
        sub = get_group(tt, mouse, "low")
        idx_all = sub.index.to_numpy()
        gap = sub["next_side_in_gap"].to_numpy()
        keep = np.isnan(gap) | (gap >= MIN_USABLE_S)
        idx, censor = idx_all[keep], gap[keep]
        n = len(idx)

        xs_c, taus_c_mean, taus_c_lo, taus_c_hi = [], [], [], []
        xs_u, taus_u_mean, taus_u_lo, taus_u_hi = [], [], [], []
        for size in [s for s in sizes if s <= n] + [n]:
            taus_c, taus_u = [], []
            n_draws = 20 if size < n else 1
            for _ in range(n_draws):
                sel = RNG.choice(n, size=size, replace=False)
                mean_c, eff_n = censored_mean_and_n(z, t, idx[sel], censor[sel])
                t_full, _, _ = breakpoints(eff_n, size, t)
                _, tau_c, _, d_c = compute_onset_and_decay(mean_c, t, (0.0, min(t_full, 3.0)))
                if d_c["skip_reason"] is None:
                    taus_c.append(tau_c)
                mean_u = z[idx[sel]].mean(axis=0)
                _, tau_u, _, d_u = compute_onset_and_decay(mean_u, t, KINETICS_METRIC_WINDOW_S)
                if d_u["skip_reason"] is None:
                    taus_u.append(tau_u)
            if taus_c:
                xs_c.append(size); taus_c_mean.append(np.mean(taus_c))
                taus_c_lo.append(np.percentile(taus_c, 25)); taus_c_hi.append(np.percentile(taus_c, 75))
            if taus_u:
                xs_u.append(size); taus_u_mean.append(np.mean(taus_u))
                taus_u_lo.append(np.percentile(taus_u, 25)); taus_u_hi.append(np.percentile(taus_u, 75))

        ax.plot(xs_c, taus_c_mean, "o-", color="darkorange", label="censored")
        ax.fill_between(xs_c, taus_c_lo, taus_c_hi, color="darkorange", alpha=0.2)
        ax.plot(xs_u, taus_u_mean, "s--", color="steelblue", label="uncensored")
        ax.fill_between(xs_u, taus_u_lo, taus_u_hi, color="steelblue", alpha=0.15)
        ax.set_title(f"{mouse} (low tercile)", fontsize=10)
        ax.set_xlabel("subset size")
        ax.legend(fontsize=8)
    axes[0].set_ylabel("fitted decay tau (s)")
    fig.suptitle("Censored vs. uncensored tau-vs-subset-size sweep")
    fig.tight_layout()
    fig.savefig(out_dir / "step1_subset_sweep_censored_vs_uncensored.png", dpi=140)
    print(f"Saved {out_dir / 'step1_subset_sweep_censored_vs_uncensored.png'}")


def step2_autocorrelation(tt, out_dir):
    print("\n" + "=" * 78)
    print("STEP 2: outcome-autocorrelation check")
    print("=" * 78)

    reward_tt = tt[tt["was_rewarded"] & tt["next_was_rewarded"].notna()].copy()

    print("\n--- 2a: P(next trial is a win | current tercile) ---\n")
    rows = []
    pooled = reward_tt.groupby("accuracy_tercile")["next_was_rewarded"].mean()
    rows.append(dict(mouse="POOLED (all mice)", low=pooled.get("low", np.nan),
                      mid=pooled.get("mid", np.nan), high=pooled.get("high", np.nan)))
    for mouse, g in reward_tt.groupby("mouse"):
        p = g.groupby("accuracy_tercile")["next_was_rewarded"].mean()
        rows.append(dict(mouse=mouse, low=p.get("low", np.nan), mid=p.get("mid", np.nan), high=p.get("high", np.nan)))
    plain_df = pd.DataFrame(rows)
    plain_df.to_csv(out_dir / "step2a_plain_autocorrelation.csv", index=False)
    print(plain_df.to_string(index=False))

    print("\n--- 2b: within contamination_fraction quartiles, does tercile still predict next-trial outcome? ---\n")
    rows = []
    for mouse, g in reward_tt.groupby("mouse"):
        g = g.copy()
        try:
            g["contam_quartile"] = pd.qcut(g["contamination_fraction"].rank(method="first"), 4, labels=["Q1(low)", "Q2", "Q3", "Q4(high)"])
        except ValueError:
            continue
        for q in ["Q1(low)", "Q2", "Q3", "Q4(high)"]:
            gq = g[g["contam_quartile"] == q]
            low = gq[gq["accuracy_tercile"] == "low"]["next_was_rewarded"]
            high = gq[gq["accuracy_tercile"] == "high"]["next_was_rewarded"]
            n_low, n_high = len(low), len(high)
            ct = pd.crosstab(gq["accuracy_tercile"].isin(["low", "high"]) & (gq["accuracy_tercile"] == "high"),
                              gq["next_was_rewarded"])
            underpowered = (n_low < 30) or (n_high < 30) or (ct.to_numpy() < 5).any() if ct.size else True
            if ct.shape == (2, 2) and not underpowered:
                chi2, p, _, _ = chi2_contingency(ct)
            else:
                chi2, p = np.nan, np.nan
            p_win_low = low.mean() if n_low else np.nan
            p_win_high = high.mean() if n_high else np.nan
            risk_diff = p_win_high - p_win_low if n_low and n_high else np.nan
            se = np.sqrt(p_win_low * (1 - p_win_low) / n_low + p_win_high * (1 - p_win_high) / n_high) if n_low and n_high else np.nan
            ci_lo, ci_hi = (risk_diff - 1.96 * se, risk_diff + 1.96 * se) if not np.isnan(se) else (np.nan, np.nan)
            rows.append(dict(mouse=mouse, quartile=q, n_low=n_low, n_high=n_high,
                              p_win_low=p_win_low, p_win_high=p_win_high, risk_diff=risk_diff,
                              ci_lo=ci_lo, ci_hi=ci_hi, chi2=chi2, chi2_p=p, underpowered=underpowered))
    quartile_df = pd.DataFrame(rows)
    quartile_df.to_csv(out_dir / "step2b_quartile_stratified_autocorrelation.csv", index=False)
    print(quartile_df.to_string(index=False))
    return plain_df, quartile_df


def step3_verdict(step1_summary, quartile_df):
    print("\n" + "=" * 78)
    print("STEP 3: per-mouse verdict")
    print("=" * 78)

    rows = []
    for mouse in sorted(step1_summary["mouse"].unique()):
        sm = step1_summary[step1_summary["mouse"] == mouse]
        low_row = sm[sm.tercile == "low"].iloc[0] if (sm.tercile == "low").any() else None

        # Divergence persistence: primary criterion is the divergence-MAGNITUDE
        # shrinkage (low-vs-high mean difference, 1.0-3.0s), not exponential-fit
        # success -- fits are too fragile at the tercile-subgroup sample size to
        # use as the persistence criterion (most fail regardless of censoring,
        # uncensored included -- see step1 printout). Coverage-gated: don't trust
        # the comparison if too few trials remain in both terciles by 1-3s.
        shrink = low_row["divergence_shrinkage_frac"] if low_row is not None else np.nan
        coverage = low_row["mean_shared_coverage_1to3s"] if low_row is not None else np.nan
        too_short = bool(low_row["window_too_short"]) if low_row is not None else True
        # The comparison window is now constructed (in step 1) to end exactly
        # where either tercile's effective N first drops below 50%, so
        # coverage should already be >=~0.5 whenever the window wasn't too
        # short to begin with -- this check is a sanity floor, not the main gate.
        coverage_ok = bool((not too_short) and pd.notna(coverage) and coverage >= 0.4)
        divergence_persists = bool(
            coverage_ok and pd.notna(shrink) and shrink < 0.5  # less than half the divergence lost
        )
        divergence_collapsed = bool(
            coverage_ok and pd.notna(shrink) and shrink >= 0.5
        )

        q = quartile_df[quartile_df["mouse"] == mouse]
        lowest_q = q[q["quartile"] == "Q1(low)"]
        content_in_lowest_q = bool(
            len(lowest_q) and not lowest_q.iloc[0]["underpowered"]
            and pd.notna(lowest_q.iloc[0]["chi2_p"]) and lowest_q.iloc[0]["chi2_p"] < 0.05
        )
        any_q_underpowered = bool(q["underpowered"].any()) if len(q) else True

        if not coverage_ok:
            verdict = "indeterminate (too few trials survive censoring in the 1-3s window to compare)"
        elif divergence_persists and not content_in_lowest_q:
            verdict = "real slow signal"
        elif content_in_lowest_q:
            verdict = "contamination-content artifact"
        elif divergence_collapsed:
            verdict = "contamination-amount artifact"
        else:
            verdict = "indeterminate/mixed"

        rows.append(dict(
            mouse=mouse, divergence_uncensored=low_row["divergence_uncensored_1to3s"] if low_row is not None else np.nan,
            divergence_censored=low_row["divergence_censored_1to3s"] if low_row is not None else np.nan,
            shrinkage_frac=shrink, shared_coverage_1to3s=coverage, coverage_ok=coverage_ok,
            divergence_persists_censored=divergence_persists,
            content_significant_lowest_quartile=content_in_lowest_q,
            any_quartile_underpowered=any_q_underpowered, verdict=verdict,
        ))
    verdict_df = pd.DataFrame(rows)
    print(verdict_df.to_string(index=False))
    return verdict_df


def main(out_dir="/tmp/censored_kinetics_out"):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    tt, z, t = load_everything()
    step1_summary = step1_censored_reanalysis(tt, z, t, out_dir)
    step1_subset_sweep(tt, z, t, out_dir)
    plain_df, quartile_df = step2_autocorrelation(tt, out_dir)
    verdict_df = step3_verdict(step1_summary, quartile_df)
    verdict_df.to_csv(out_dir / "step3_per_mouse_verdict.csv", index=False)
    print(f"\nAll outputs saved to {out_dir}")


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "/tmp/censored_kinetics_out"
    main(out)
