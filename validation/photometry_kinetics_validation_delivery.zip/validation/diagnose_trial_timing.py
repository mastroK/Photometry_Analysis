"""
Steps 1-2 of the contamination-vs-real-slow-signal follow-up to
validation/diagnose_kinetics_shape.py: before trusting that the
Rolling_Accuracy-tercile divergence found there reflects a real slow
single-trial signal, check whether it could instead be an artifact of the
fixed 5.4s analysis window running into the NEXT trial's own events --
trials in this task are only ~2-5s apart (animal-paced, no hardware ITI
found anywhere in this repo's config/task code).

Step 1: for every trial (except the last trial of each session), compute
the time from THIS trial's outcome (side_in_s -- confirmed
photometry_outcome_index == photometry_side_in_index in behavior/sync.py,
i.e. reward delivery has no independently-timestamped event in this rig)
to the NEXT trial's first relevant event. Two candidate "next event"
markers are reported, since they test different things:
  - next_center_in_gap: time to the next trial's center_in_s --
    behavioral re-engagement speed (what "do they re-engage faster after
    wins" literally asks).
  - next_side_in_gap: time to the next trial's own side_in_s -- the
    actual contamination source for a side_in-aligned window (this is
    when the NEXT trial's own reward-locked transient begins).

Step 2: split trials into Rolling_Accuracy terciles (same convention as
diagnose_kinetics_shape.py -- rank-based qcut, since Rolling_Accuracy only
takes 6 discrete values) and test whether either gap differs by tercile,
using Mann-Whitney U + Cliff's delta + bootstrap CI -- reusing
run_age_comparison.py's own cliffs_delta/bootstrap_median_diff_ci rather
than writing new statistical code (confirmed no multiple-comparisons
correction convention exists anywhere in this pipeline).

STOPS HERE per the user's explicit instruction -- does not censor/re-run
the original kinetics diagnostic (that's Step 3, a separate follow-up).

Usage: python validation/diagnose_trial_timing.py [out_dir]
"""

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu

sys.path.insert(0, str(Path(__file__).parent.parent))

from run_age_comparison import cliffs_delta, bootstrap_median_diff_ci  # noqa: E402

DATA_DIR = Path("outputs_fixed/rpe_analysis_pooled")


def load_and_compute_gaps():
    tt = pd.read_parquet(DATA_DIR / "pooled_trial_table.parquet")

    parts = []
    for (mouse, date), g in tt.groupby(["mouse", "date"], sort=False):
        g = g.sort_values("side_in_s").copy()
        g["next_center_in_s"] = g["center_in_s"].shift(-1)
        g["next_side_in_s"] = g["side_in_s"].shift(-1)
        g["is_last_trial_of_session"] = g["next_side_in_s"].isna()
        parts.append(g)
    tt = pd.concat(parts, ignore_index=False).sort_index()

    tt["next_center_in_gap"] = tt["next_center_in_s"] - tt["side_in_s"]
    tt["next_side_in_gap"] = tt["next_side_in_s"] - tt["side_in_s"]
    return tt


def step1_report(tt, out_dir):
    n_total = len(tt)
    n_last = int(tt["is_last_trial_of_session"].sum())
    print(f"=== Step 1: inter-trial timing ===")
    print(f"{n_total} total trials, {n_last} ({n_last/n_total:.1%}) are the last trial of "
          f"their session (no valid next event, excluded from gap stats below)")

    valid = tt.loc[~tt["is_last_trial_of_session"]]
    for col, label in [("next_center_in_gap", "outcome -> next center_in (re-engagement)"),
                        ("next_side_in_gap", "outcome -> next side_in (next outcome / contamination source)")]:
        vals = valid[col].dropna().to_numpy()
        frac_within_window = (vals <= 5.4).mean()
        print(f"\n{label}: n={len(vals)}")
        print(f"  mean={vals.mean():.3f}s median={np.median(vals):.3f}s "
              f"IQR=[{np.percentile(vals,25):.3f}, {np.percentile(vals,75):.3f}]s "
              f"min={vals.min():.3f}s max={vals.max():.3f}s")
        print(f"  fraction of trials where this event falls WITHIN the fixed 5.4s window: "
              f"{frac_within_window:.1%}")

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    for ax, col, label in zip(
        axes,
        ["next_center_in_gap", "next_side_in_gap"],
        ["outcome -> next center_in", "outcome -> next side_in"],
    ):
        vals = valid[col].dropna().to_numpy()
        ax.hist(vals, bins=60, range=(0, 15), color="steelblue", alpha=0.85)
        ax.axvline(5.4, color="crimson", ls="--", lw=1.5, label="5.4s window edge")
        ax.axvline(np.median(vals), color="black", lw=1.5, label=f"median={np.median(vals):.2f}s")
        ax.set_xlabel(f"time (s): {label}")
        ax.set_ylabel("trial count")
        ax.legend(fontsize=8)
    fig.suptitle("Step 1: inter-trial-event timing distribution (all mice/sessions pooled)")
    fig.tight_layout()
    fig.savefig(out_dir / "step1_intertrial_timing.png", dpi=140)
    print(f"\nSaved {out_dir / 'step1_intertrial_timing.png'}")
    return valid


def step2_report(valid, out_dir):
    print(f"\n=== Step 2: does inter-trial timing depend on recent win/loss history? ===")
    valid = valid.copy()
    valid["accuracy_tercile"] = (
        valid.groupby("mouse")["Rolling_Accuracy"]
        .transform(lambda s: pd.qcut(s.rank(method="first"), 3, labels=["low", "mid", "high"]))
    )

    rows = []
    for gap_col, label in [("next_center_in_gap", "outcome->next_center_in"),
                           ("next_side_in_gap", "outcome->next_side_in")]:
        # pooled across all mice
        low = valid.loc[valid["accuracy_tercile"] == "low", gap_col].dropna().to_numpy()
        high = valid.loc[valid["accuracy_tercile"] == "high", gap_col].dropna().to_numpy()
        stat, p = mannwhitneyu(low, high, alternative="two-sided")
        delta = cliffs_delta(low, high)
        ci_lo, ci_hi = bootstrap_median_diff_ci(low, high)
        rows.append(dict(
            gap=label, group="POOLED (all mice)", n_low=len(low), n_high=len(high),
            median_low=np.median(low), median_high=np.median(high),
            median_diff=np.median(low) - np.median(high),
            ci_lo=ci_lo, ci_hi=ci_hi, cliffs_delta=delta, mwu_stat=stat, mwu_p=p,
        ))

        # per mouse
        for mouse, g in valid.groupby("mouse"):
            low = g.loc[g["accuracy_tercile"] == "low", gap_col].dropna().to_numpy()
            high = g.loc[g["accuracy_tercile"] == "high", gap_col].dropna().to_numpy()
            if len(low) < 5 or len(high) < 5:
                continue
            stat, p = mannwhitneyu(low, high, alternative="two-sided")
            delta = cliffs_delta(low, high)
            ci_lo, ci_hi = bootstrap_median_diff_ci(low, high)
            rows.append(dict(
                gap=label, group=mouse, n_low=len(low), n_high=len(high),
                median_low=np.median(low), median_high=np.median(high),
                median_diff=np.median(low) - np.median(high),
                ci_lo=ci_lo, ci_hi=ci_hi, cliffs_delta=delta, mwu_stat=stat, mwu_p=p,
            ))

    result = pd.DataFrame(rows)
    result.to_csv(out_dir / "step2_tercile_gap_comparison.csv", index=False)
    print(result.to_string(index=False))
    print(f"\nSaved {out_dir / 'step2_tercile_gap_comparison.csv'}")

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    for ax, gap_col, label in zip(
        axes, ["next_center_in_gap", "next_side_in_gap"],
        ["outcome -> next center_in", "outcome -> next side_in"],
    ):
        for tercile, color in [("low", "crimson"), ("mid", "gray"), ("high", "seagreen")]:
            vals = valid.loc[valid["accuracy_tercile"] == tercile, gap_col].dropna().to_numpy()
            ax.hist(vals, bins=50, range=(0, 15), histtype="step", color=color, lw=1.8,
                    density=True, label=f"{tercile} (n={len(vals)}, med={np.median(vals):.2f}s)")
        ax.axvline(5.4, color="black", ls="--", lw=1, alpha=0.6)
        ax.set_xlabel(f"time (s): {label}")
        ax.set_ylabel("density")
        ax.legend(fontsize=7)
    fig.suptitle("Step 2: inter-trial gap by Rolling_Accuracy tercile (pooled across mice)")
    fig.tight_layout()
    fig.savefig(out_dir / "step2_tercile_gap_distributions.png", dpi=140)
    print(f"Saved {out_dir / 'step2_tercile_gap_distributions.png'}")
    return result


def main(out_dir="/tmp/trial_timing_diag_out"):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    tt = load_and_compute_gaps()
    valid = step1_report(tt, out_dir)
    step2_report(valid, out_dir)


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "/tmp/trial_timing_diag_out"
    main(out)
