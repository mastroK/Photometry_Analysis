"""
Diagnostic (read-only against pipeline outputs, does not modify
alignment/kinetics.py or any config): is the trial-averaged single-
exponential decay fit in alignment/kinetics.py describing a real discrete
per-trial transient, or could it be an artifact of averaging heterogeneous
trials (peak-time jitter, or a slow win/loss-history-tracking component)?

Produces, per prioritized (mouse, was_rewarded) group:
  1. Spaghetti plot: individual z-scored trial traces + trial mean + fitted
     exponential, full window including pre-event baseline.
  2. Per-trial peak-time histogram within KINETICS_METRIC_WINDOW_S.
  4. Tau-vs-subset-size sweep: refit on random trial subsets of increasing
     size, see whether tau grows with n (smearing) or stays flat (real).

Plus, across all 11 mice (reward condition): individual-trial fit success
rate/tau distribution as a noise floor, and one streak-tercile PETH overlay
(reusing viz.traces.plot_peth_by_group) for a representative mouse.

Usage: python validation/diagnose_kinetics_shape.py [out_dir]
"""

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent.parent))

from alignment.kinetics import compute_onset_and_decay, _exp_decay_model
from config.params import KINETICS_METRIC_WINDOW_S
from viz.traces import plot_peth_by_group

DATA_DIR = Path("outputs_fixed/rpe_analysis_pooled")
PRIORITY = ["WCL31", "WCL28", "WCL29"]  # two flagged non-decaying cases + one clean comparison
RNG = np.random.default_rng(0)


def load():
    tt = pd.read_parquet(DATA_DIR / "pooled_trial_table.parquet")
    peth = np.load(DATA_DIR / "peth_windows.npz")
    return tt, peth["zscore_windows"], peth["peth_time"]


def oriented_group(tt, z, mouse, was_rewarded):
    mask = ((tt["mouse"] == mouse) & (tt["was_rewarded"] == was_rewarded)).to_numpy()
    trials = z[mask]
    win_mask_for_sign = None
    return trials, mask


def sign_orient(trials, t, metric_window_s):
    win = (t >= metric_window_s[0]) & (t <= metric_window_s[1])
    mean_in_window = trials[:, win].mean()
    sign = 1.0 if mean_in_window >= 0 else -1.0
    return trials * sign, sign


def plot_spaghetti_and_fit(mouse, trials, t, ax, n_sample=60):
    sample_idx = RNG.choice(len(trials), size=min(n_sample, len(trials)), replace=False)
    for i in sample_idx:
        ax.plot(t, trials[i], color="steelblue", alpha=0.07, lw=0.6)
    mean_trace = trials.mean(axis=0)
    ax.plot(t, mean_trace, color="black", lw=2, label=f"mean (n={len(trials)})")

    onset, tau, r2, diag = compute_onset_and_decay(mean_trace, t, KINETICS_METRIC_WINDOW_S)
    if diag["skip_reason"] is None:
        peak_t = diag["peak_time_s"]
        t_post = t[(t >= peak_t) & (t <= KINETICS_METRIC_WINDOW_S[1])]
        # reconstruct fit curve: need amplitude/offset -- refit quickly via the
        # same helper is overkill; instead just re-derive from diag + tau by
        # calling curve_fit inline is what compute_onset_and_decay already did.
        # Simplest: recompute using the same logic path (cheap) for plotting only.
        post_mask = t >= peak_t
        post_t, post_y = t[post_mask & (t <= KINETICS_METRIC_WINDOW_S[1])], mean_trace[post_mask & (t <= KINETICS_METRIC_WINDOW_S[1])]
        from scipy.optimize import curve_fit
        t_rel = post_t - peak_t
        try:
            popt, _ = curve_fit(_exp_decay_model, t_rel, post_y, p0=[post_y[0]-post_y[-1], tau, post_y[-1]], maxfev=5000)
            ax.plot(post_t, _exp_decay_model(t_rel, *popt), color="crimson", lw=2, ls="--", label=f"fit tau={tau:.2f}s")
        except Exception:
            pass
    ax.axvline(0, color="gray", ls=":", lw=1)
    ax.axhline(0, color="gray", ls="--", lw=0.5)
    ax.axvspan(*KINETICS_METRIC_WINDOW_S, color="orange", alpha=0.05)
    title = f"{mouse} reward, n={len(trials)}\nonset={onset:.2f}s tau={tau:.2f}s" if diag["skip_reason"] is None else \
            f"{mouse} reward, n={len(trials)}\nDECAY SKIPPED: {diag['skip_reason'][:50]}"
    ax.set_title(title, fontsize=9)
    ax.legend(fontsize=7, loc="upper right")
    return diag


def peak_time_histogram(trials, t, ax, mouse, metric_window_s):
    win = (t >= metric_window_s[0]) & (t <= metric_window_s[1])
    t_win = t[win]
    peak_times = t_win[np.argmax(trials[:, win], axis=1)]
    ax.hist(peak_times, bins=20, color="steelblue", alpha=0.8)
    ax.axvline(peak_times.mean(), color="black", lw=1.5)
    ax.set_title(f"{mouse}: per-trial peak time\nmean={peak_times.mean():.2f}s sd={peak_times.std():.2f}s", fontsize=9)
    ax.set_xlabel("peak time (s)")
    return peak_times


def subset_size_sweep(trials, t, mouse, ax, sizes=(3, 5, 8, 12, 20, 30, 50), n_draws=30):
    n = len(trials)
    sizes = [s for s in sizes if s <= n] + [n]
    results = []
    for size in sizes:
        taus = []
        for _ in range(n_draws if size < n else 1):
            idx = RNG.choice(n, size=size, replace=False)
            sub_mean = trials[idx].mean(axis=0)
            _, tau, _, diag = compute_onset_and_decay(sub_mean, t, KINETICS_METRIC_WINDOW_S)
            if diag["skip_reason"] is None:
                taus.append(tau)
        results.append((size, taus))

    xs, means, lo, hi, n_ok = [], [], [], [], []
    for size, taus in results:
        if len(taus) == 0:
            continue
        xs.append(size)
        means.append(np.mean(taus))
        lo.append(np.percentile(taus, 25))
        hi.append(np.percentile(taus, 75))
        n_ok.append(len(taus))
    ax.plot(xs, means, "o-", color="darkorange")
    ax.fill_between(xs, lo, hi, color="darkorange", alpha=0.2)
    for x, y, n_success, draws in zip(xs, means, n_ok, [d if s < n else 1 for s, d in [(s, n_draws) for s in xs]]):
        pass
    ax.set_xlabel("subset size (n trials averaged)")
    ax.set_ylabel("fitted decay tau (s)")
    ax.set_title(f"{mouse}: tau vs. averaging-subset size\n(flat = real shared kinetic, rising = smearing)", fontsize=9)
    return xs, means, lo, hi


def individual_trial_fit_noise_floor(tt, z, t):
    rows = []
    for mouse in tt["mouse"].unique():
        mask = ((tt["mouse"] == mouse) & (tt["was_rewarded"])).to_numpy()
        trials = z[mask]
        n_attempt = min(200, len(trials))
        idx = RNG.choice(len(trials), size=n_attempt, replace=False)
        n_ok, taus = 0, []
        for i in idx:
            trial, sign = sign_orient(trials[i:i+1], t, KINETICS_METRIC_WINDOW_S)
            _, tau, _, diag = compute_onset_and_decay(trial[0], t, KINETICS_METRIC_WINDOW_S)
            if diag["skip_reason"] is None:
                n_ok += 1
                taus.append(tau)
        rows.append(dict(mouse=mouse, n_attempted=n_attempt, n_fit_ok=n_ok,
                          frac_ok=n_ok / n_attempt, tau_median=np.median(taus) if taus else np.nan))
    return pd.DataFrame(rows)


def main(out_dir="/tmp/kinetics_diag_out"):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    tt, z, t = load()

    # --- 1+2+4: per prioritized mouse, spaghetti+fit, peak-time hist, subset sweep ---
    fig, axes = plt.subplots(len(PRIORITY), 3, figsize=(15, 4 * len(PRIORITY)))
    for row, mouse in enumerate(PRIORITY):
        trials, _ = oriented_group(tt, z, mouse, True)
        trials_oriented, sign = sign_orient(trials, t, KINETICS_METRIC_WINDOW_S)
        print(f"{mouse}: n_trials={len(trials)}, sign={sign}")

        ax0 = axes[row, 0]
        plot_spaghetti_and_fit(mouse, trials_oriented, t, ax0)
        ax0.set_xlim(-2, 3.5)

        ax1 = axes[row, 1]
        peak_time_histogram(trials_oriented, t, ax1, mouse, KINETICS_METRIC_WINDOW_S)

        ax2 = axes[row, 2]
        subset_size_sweep(trials_oriented, t, mouse, ax2)

    fig.tight_layout()
    fig.savefig(out_dir / "kinetics_shape_diagnostics.png", dpi=140)
    print(f"Saved {out_dir / 'kinetics_shape_diagnostics.png'}")

    # --- individual-trial fit noise floor, all mice, reward condition ---
    noise_floor = individual_trial_fit_noise_floor(tt, z, t)
    noise_floor.to_csv(out_dir / "individual_trial_fit_noise_floor.csv", index=False)
    print("\n=== Individual-trial fit noise floor (reward condition) ===")
    print(noise_floor.to_string(index=False))

    # --- streak-tercile PETH overlay for one representative mouse ---
    for mouse in PRIORITY:
        mask = ((tt["mouse"] == mouse) & (tt["was_rewarded"])).to_numpy()
        sub_tt = tt.loc[mask].copy()
        sub_z = z[mask]
        # Rolling_Accuracy only takes 6 discrete values (k/5 over a 5-trial
        # window), so qcut on the raw values hits duplicate-edge errors --
        # rank first (ties broken arbitrarily but evenly) to guarantee 3
        # equal-sized bins regardless of how few distinct values there are.
        terciles = pd.qcut(sub_tt["Rolling_Accuracy"].rank(method="first"), 3, labels=["low", "mid", "high"])
        fig2, ax = plt.subplots(figsize=(6, 4.5))
        try:
            # plot_peth_by_group's first ("dff_windows") panel is required and
            # indexed directly -- we only have z-scored windows here, so pass
            # them as both positional args (single, correctly-labeled panel).
            plot_peth_by_group(
                t, sub_z, terciles,
                channel_label="z-score", title_prefix=f"{mouse} reward, by Rolling_Accuracy tercile",
                group_order=["low", "mid", "high"],
            )
            plt.gcf().savefig(out_dir / f"streak_tercile_{mouse}.png", dpi=140)
            print(f"Saved streak_tercile_{mouse}.png")
        except Exception as e:
            print(f"streak tercile plot failed for {mouse}: {e}")
        plt.close("all")

    print(f"\nAll diagnostics saved to {out_dir}")


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "/tmp/kinetics_diag_out"
    main(out)
